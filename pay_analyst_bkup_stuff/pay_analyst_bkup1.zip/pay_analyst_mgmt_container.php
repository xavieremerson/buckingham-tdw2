<?
//BRG
include('inc_header.php');
?>
		<!-- START TABLE 1 -->
		<table width="100%" height="100%" border="0" cellspacing="1" cellpadding="0">
			<tr> 
				<td valign="top">
				<?
				include('pay_analyst_mgmt.php');
				?>
				</td>
			</tr>
		</table>
		<!-- END TABLE 1 -->
<?
include('inc_footer.php'); 
?>

