<style>
<!--
.vert_1 {
	writing-mode: tb-rl;
	filter: flipv fliph;
	border-collapse: collapse;
	border: .05em solid #ccc;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	font-weight: bold;
	color: 666;
}

.text_xl {
	border-collapse: collapse;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}

.tbl_xl {
	border-collapse: collapse; 
	border: .05em solid #ccc; 
}

td.tdx { 
	border-collapse: collapse; 
	border: .05em solid #ccc; 
} 
.valred {
color:#FF0000;
}
.valgreen {
	color:#009900;
	font-weight: bold;
}
.pplname{
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	font-weight: bold;
	color: 666;
}
input.text{
	font-family: Verdana;
	font-size: 12px;
	font-weight: bold;
	color: 00F;
}
.num_1{
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	font-weight: bold;
	color: 666;
	text-align: right;
}
#scrollGrid_1 {
	width: 750px;
	height: 500px;
	padding: 1px;
	border: 0px solid #cc0000;
	overflow: scroll; 
}
-->
</style> 